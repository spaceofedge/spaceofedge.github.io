//Redirecting Loader by Mr. Alien
//Inspired from some random image online