A Pen created at CodePen.io. You can find this one at http://codepen.io/mr_alien/pen/FDLjg.

 Animated loader when redirecting a user to another page